package DBConnections;

import java.sql.*;

public class DBConnection

{
private static Connection con =null;
   static
	{	
		try
		{
			System.out.println("================RAJKUMAR");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			con = DriverManager.getConnection(url,"SYSTEM","rajkumar");
			System.out.println("con======="+con);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
  private DBConnection() {}
  public static Connection getConnection()
   {
	   return con;
   }
  
 /* public static Connection getConnection() {//connecting db through wildfly server
	  Connection con =null;
	  try{
		  final Context ctx = new InitialContext();
		  final DataSource ds = (DataSource) ctx.lookup("java:jboss/datasources/ExampleDS");//jndi name through standalone.xml
		  con= ds.getConnection();
			System.out.println("Conection==============="+con);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	 return con; 
  }*/
}
