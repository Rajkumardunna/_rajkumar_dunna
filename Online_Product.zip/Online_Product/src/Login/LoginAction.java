package Login;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import DBConnections.DBConnection;

public class LoginAction extends Action 
{
	int k=0;
	Connection con=DBConnection.getConnection();
	private final static String  SUCCESS = "success";
	private final static String  FAILURE = "failure";
	private final static String  MENUS = "menus";

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception 
	{
		try
		{

			
			LoginForm logf=(LoginForm) form;
			//RegServlet logf=(RegServlet) form;
			PreparedStatement ps=con.prepareStatement("select * from rajkumar where uname=? and pass1=?");
			ps.setString(1,logf.getUname());
			ps.setString(2, logf.getPass1());
			k=ps.executeUpdate();
			
			if(k>0)
			{
				
				return mapping.findForward("success");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

		return mapping.findForward("failure");
	}

}	

















































//		DBConnection.getConnection();
//
//		System.out.println("Connection=============="+DBConnection.getConnection());
//
//
//
//		try
//		{
//			RegServlet lf = (RegServlet) form;
//			System.out.println("--------------------------------------");
//
//			PreparedStatement ps=con.prepareStatement("select * from RAJKUMAR where uname=? and pass1=?");
//
//			
//			ps.setString(1,request.getParameter("uname"));
//			ps.setString(2,request.getParameter("pass1"));
//			
//			ResultSet rs=ps.executeQuery();
//			
//			//ArrayList<> al=rs
//			
//			//LoginForm lf= (LoginForm) form;
//			
//			System.out.println("RAJKUKMAR++++++++++++++++++++++++++6666666666666666666");
//			
//
//
//				lf.setUname(rs.getString(2));
//				lf.setPass1(rs.getString(5));
//System.out.println("RAJKUKMAR++++++++++++++++++++++++++5555555555555555555");
//				
//			
//		}
//			catch(Exception e)
//			{
//				e.printStackTrace();
//			}
//			return mapping.findForward("menus");
//		}
//
//	}