package Login;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import DBConnections.DBConnection;

public class RegisterAction extends Action {

	int k=0;

	private final static String  SUCCESS = "success";
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		System.out.println("Connection=============="+DBConnection.getConnection());

		RegisterForm rs = (RegisterForm) form;
		
		System.out.println("1111111111111111111111111111111"+form);
		System.out.println("666666666666666666"+rs);

		try
		{
			Connection con = DBConnection.getConnection();
			
			System.out.println("Register==========="+con);
			System.out.println("44444444444444444");
			PreparedStatement ps=con.prepareStatement("insert into rajkumar values(?,?,?,?,?,?,?,?,?,?,?)");
			System.out.println("5555555555555555");

			ps.setString(1, rs.getFname());
			ps.setString(2, rs.getUname());
			ps.setLong(3, rs.getPnumber());
			ps.setString(4, rs.getEmail());
			ps.setString(5, rs.getPass1());
			ps.setString(6, rs.getPass2());
			ps.setString(7, rs.getHnum());
			ps.setString(8, rs.getVillage());
			ps.setString(9, rs.getState());
			ps.setLong(10, rs.getPincode());
			ps.setString(11, rs.getGender());
System.out.println("2222222222222222");

			k=ps.executeUpdate();

			System.out.println("DATA INSERTED SUCCESSFULLY....");

			if(k>0)
			{
				return mapping.findForward("success");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;

	}

}