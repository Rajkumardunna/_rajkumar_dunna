package Login;


public class LoginForm extends org.apache.struts.action.ActionForm {

	private String uname;
	private String pass1;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass1() {
		return pass1;
	}
	public void setPass1(String pass1) {
		this.pass1 = pass1;
	}


}

